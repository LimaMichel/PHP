<?php
	$uploaddir = 'uploads/';

	$uploadfile = $uploaddir . $_FILES['arquivo']['name'];

	if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $uploadfile)){
		echo '<html>
				<div class="jumbotron">
					<div class="container">
						<p>Arquivo Enviado</p>
					</div>
				</div>
			 </html>';
	}
	else{
		echo '<html>
				<div class="jumbotron">
					<div class="container">
						<p>Arquivo Não Enviado</p>
					</div>
				</div>
			 </html>';
	}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		<title>Notificação</title>
    </head>
    
    <body>
        <div class="jumbotron">
        <div class="container">
			
			<div class="form-actions">
				<a href="index.php" type="btn" class="btn btn-default">Voltar</a>
			</div>

		</div>
		</div>        
    </body>
</html>