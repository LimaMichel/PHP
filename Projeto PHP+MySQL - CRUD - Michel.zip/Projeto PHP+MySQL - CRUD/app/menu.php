<?php
session_start();

//Caso o usuário não esteja autenticado, limpa os dados e redireciona
if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {
	
	//Destrói Sessão
	session_destroy();

	//Limpa
	unset ($_SESSION['email']);
	unset ($_SESSION['senha']);
	
	//Redireciona para a página de autenticação
	header('location:index.php');
}

$login = $_SESSION['email'];

echo '<html>
		<div class="jumbotron">
			<div class="container">
				<h2>Bem vindo usuario: '.$login.' !! <a href="index.php" class="btn btn-success">Sair</a></h2>
			</div>
		</div>
	</html>';
;

?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Menu</title>
    </head>
    
    <body>
        <div class="jumbotron">
        <div class="container">						
			<h3>Escolha uma das opções:</h3>
			
			<div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
                <a href="read.php"><label class="control-label">Meus Dados</label></a>
				</br>
				<a href="lista.php"><label class="control-label">Todas Faculdades Cadastradas</label></a>
            </div>
			
		</div>
		</div>        
    </body>
</html>