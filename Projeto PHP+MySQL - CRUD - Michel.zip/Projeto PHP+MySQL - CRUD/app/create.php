<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Cadastro Faculdade</title>
    </head>
    
    <body>
        <div class="container">
            <div clas="span10 offset1">
                <div class="row">
                    <h3 class="well"> Cadastrar nova Faculdade </h3>
                    <form class="form-horizontal" action="create.php" method="post">
                        
                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Instituição</label>
                            <div class="controls">
                                <input size= "25" name="nome" type="text" placeholder="Nome" required="" value="<?php echo !empty($nome)?$nome: '';?>">
                                <?php if(!empty($nomeErro)): ?>
                                    <span class="help-inline"><?php echo $nomeErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        
                        <div class="control-group <?php echo !empty($cnpjErro)?'error ': '';?>">
                            <label class="control-label">CNPJ</label>
                            <div class="controls">
                                <input size="25" data-mask="XX.XXX.XXX/0001-XX" name="cnpj" type="text" placeholder="CNPJ" required="" value="<?php echo !empty($cnpj)?$cnpj: '';?>">
                                <?php if(!empty($cnpjErro)): ?>
                                <span class="help-inline"><?php echo $cnpjErro;?></span>
                                <?php endif;?>
							</div>
                        </div>
                        
                        
                        <div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
                            <label class="control-label">Email</label>
                            <div class="controls">
                                <input size="25" name="email" type="text" placeholder="Email" required="" value="<?php echo !empty($email)?$email: '';?>">
                                <?php if(!empty($emailErro)): ?>
                                <span class="help-inline"><?php echo $emailErro;?></span>
                                <?php endif;?>
                        </div>
                        </div>
                        
                        <div class="control-group <?php echo !empty($senhaErro)?'error ': '';?>">
                            <label class="control-label" >Senha</label>
                            <div class="controls">
                                <input size="25" name="senha" type="text" placeholder="Senha" required="" value="<?php echo !empty($senha)?$senha: '';?>">
                                <?php if(!empty($senhaErro)): ?>
                                <span class="help-inline"><?php echo $senhaErro;?></span>
                                <?php endif;?>
                        </div>
                        </div>
                        <div class="form-actions">
                            <br/>
                
                            <button type="submit" class="btn btn-success">Cadastrar</button>
                            <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                        
                        </div>
                    </form>
                </div>
        </div>
    </body>
</html>


<?php
    require '../config/banco.php';
    
    if(!empty($_POST))
    {
        //Acompanha os erros de validação
        $nomeErro = null;
        $cnpjErro = null;
        $emailErro = null;
        $senhaErro = null;
        
        $nome = $_POST['nome'];
        $cnpj = $_POST['cnpj'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
        //Validaçao dos campos:
        $validacao = true;
        
		if(empty($nome))
        {
            $nomeErro = 'Por favor digite o seu nome!';
            $validacao = false;
        }
        
        if(empty($cnpj))
        {
            $cnpjErro = 'Por favor digite o seu cnpj!';
            $validacao = false;
        }
        
        if(empty($email))
        {
            $telefoneErro = 'Por favor digite o endereço de email';
            $validacao = false;
        }
        elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) 
        {
            $emailError = 'Por favor digite um endereço de email válido!';
            $validacao = false;
        }
        
        if(empty($senha))
        {
            $senhaErro = 'Por favor digite sua senha';
            $validacao = false;
        }
        
        //Inserindo no Banco:
        if($validacao)
        {
			try{
				$conexao = Banco::conectar();
			
				$sql = "INSERT INTO t_faculdades (cd_faculdade, nm_faculdade, cnpj_faculdade, email_faculdade, senha_faculdade)
						VALUES(null,'$nome','$cnpj','$email','$senha')";

				mysql_query($sql,$conexao);

				$conexao = Banco::desconectar();
				
				header("Location: index.php");
			}
			
			catch(Exception $ex){
				die('ERRO na base de dados ao cadastrar '.$exception->getMessage());
			}
        }
    }
?>
