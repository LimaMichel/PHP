<?php
session_start();

if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {

	session_destroy();

	unset ($_SESSION['email']);
	unset ($_SESSION['senha']);

	header('location:index.php');
}

$login = $_SESSION['email'];   
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Atualização dos Dados</title>
    </head>
    
    <body>
	
	</br>
        <div class="container">
            <div clas="span10 offset1">
				<a href="index.php" class="btn btn-success">Sair</a>
				
				<div class="row">
                    <h3 class="well">Tem Certeza que deseja excluir sua conta?</h3>
				</div>
				
                <form class="form-horizontal" action="delete.php" method="post">
                    <div class="form-actions">
                        <br/>
                        <a href="delete.php" type="btn" class="btn btn-default">SIM</a>
							
						<a href="read.php" type="btn" class="btn btn-default">NÃO</a>                       
                    </div>
                </form>
				
            </div>		
		</div>
		
    </body>
</html>