<?php
session_start();

if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {

	session_destroy();

	unset ($_SESSION['email']);
	unset ($_SESSION['senha']);

	header('location:index.php');
}

$login = $_SESSION['email'];
	
/***** Pesquisando Dados *****/

require '../config/banco.php';
    try{
        $conexao = Banco::conectar();
			
		$sql = "SELECT * FROM t_faculdades WHERE email_faculdade='$login'";

		$result = mysql_query($sql,$conexao);
		
		while($sql = mysql_fetch_array($result)){
			$nome = $sql["nm_faculdade"];
			$cnpj = $sql["cnpj_faculdade"];
			$email = $sql["email_faculdade"];
		}
		$conexao = Banco::desconectar();
    }
	catch(Exception $ex){
		die('Erro na Base de Dados: '.$exception->getMessage());
	}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Meus Dados</title>
    </head>
    <body>
	</br>
        <div class="container">           
            <div class="span10 offset1">
				
                <a href="index.php" class="btn btn-success">Sair</a>
				
				<div class="row">
                    <h3 class="well"> Meus Dados </h3>
                </div>
                
                <div class="form-horizontal">                   
                    <div class="control-group">
                        <label class="control-label">Instituição</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?=$nome?>
                            </label>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label">CNPJ</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $cnpj;?>
                            </label>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label">Email</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $email;?>
                            </label>
                        </div>
                    </div>
                    
                    <br/>
                    <div class="form-actions">
                        <a href="menu.php" type="btn" class="btn btn-default">Voltar</a>
						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="update.php" class="btn btn-success">Atualizar Dados</a>
						
						&nbsp;&nbsp;&nbsp;
						<a href="confirma_delecao.php" class="btn btn-success">Remover Conta</a>
                    </div>
                    
                </div>
            </div>
        </div>
    </body>
</html>

