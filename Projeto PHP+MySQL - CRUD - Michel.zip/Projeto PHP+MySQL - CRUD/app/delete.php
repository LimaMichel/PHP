<?php
	session_start();

	if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {

		session_destroy();

		unset ($_SESSION['email']);
		unset ($_SESSION['senha']);

		header('location:index.php');
	}

	$login = $_SESSION['email'];
	
	require '../config/banco.php';
	
	try{
        //Pesquisando id
		
		$conexao = Banco::conectar();
			
		$sql = "SELECT cd_faculdade FROM t_faculdades WHERE email_faculdade='$login'";

		$result = mysql_query($sql,$conexao);
		
		while($sql = mysql_fetch_array($result)){
			$id = $sql["cd_faculdade"];
		}
		
		//Deletando		
		$sql = "DELETE FROM t_faculdades WHERE cd_faculdade=$id ;";

		mysql_query($sql,$conexao);

		$conexao = Banco::desconectar();
				
		header("Location: index.php");
	}
			
	catch(Exception $ex){
		die('ERRO ao Excluir: '.$exception->getMessage());
	}
?>
