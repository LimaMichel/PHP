<?php
session_start();

if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {

	session_destroy();

	unset ($_SESSION['email']);
	unset ($_SESSION['senha']);

	header('location:index.php');
}

$login = $_SESSION['email'];
	
/***** Pesquisando Dados *****/

require '../config/banco.php';
    try{
        $conexao = Banco::conectar();
			
		$sql = "SELECT * FROM t_faculdades WHERE email_faculdade='$login'";

		$result = mysql_query($sql,$conexao);
		
		while($sql = mysql_fetch_array($result)){
			$id = $sql["cd_faculdade"];
			$nome = $sql["nm_faculdade"];
			$cnpj = $sql["cnpj_faculdade"];
			$email = $sql["email_faculdade"];
			$senha = $sql["senha_faculdade"];
		}
		$conexao = Banco::desconectar();
    }
	catch(Exception $ex){
		die('Erro na Base de Dados: '.$exception->getMessage());
	}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Atualização dos Dados</title>
    </head>
    
    <body>
        <div class="container">
            <div clas="span10 offset1">
                
				</br>
                <a href="index.php" class="btn btn-success">Sair</a>
				
				<div class="row">
                    <h3 class="well"> Cadastrar nova Faculdade </h3>
                    <form class="form-horizontal" action="update.php" method="post">
                        
                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Instituição</label>
                            <div class="controls">
                                <input size= "25" name="nome" type="text" placeholder="Nome" required="" value="<?php echo !empty($nome)?$nome: '';?>">
                                <?php if(!empty($nomeErro)): ?>
                                    <span class="help-inline"><?php echo $nomeErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        
                        <div class="control-group <?php echo !empty($cnpjErro)?'error ': '';?>">
                            <label class="control-label">CNPJ</label>
                            <div class="controls">
                                <input size="25" data-mask="XX.XXX.XXX/0001-XX" name="cnpj" type="text" placeholder="CNPJ" required="" value="<?php echo !empty($cnpj)?$cnpj: '';?>">
                                <?php if(!empty($cnpjErro)): ?>
                                <span class="help-inline"><?php echo $cnpjErro;?></span>
                                <?php endif;?>
							</div>
                        </div>
                        
                        
                        <div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
                            <label class="control-label">Email</label>
                            <div class="controls">
                                <input size="25" name="email" type="text" placeholder="Email" required="" value="<?php echo !empty($email)?$email: '';?>">
                                <?php if(!empty($emailErro)): ?>
                                <span class="help-inline"><?php echo $emailErro;?></span>
                                <?php endif;?>
                        </div>
                        </div>
                        
                        <div class="control-group <?php echo !empty($senhaErro)?'error ': '';?>">
                            <label class="control-label" >Senha</label>
                            <div class="controls">
                                <input size="25" name="senha" type="text" placeholder="Senha" required="" value="<?php echo !empty($senha)?$senha: '';?>">
                                <?php if(!empty($senhaErro)): ?>
                                <span class="help-inline"><?php echo $senhaErro;?></span>
                                <?php endif;?>
                        </div>
                        </div>
						
                        <div class="form-actions">
                            <br/>
                            <button type="submit" class="btn btn-success">Atualizar</button>
							
							
							<a href="menu.php" type="btn" class="btn btn-default">Voltar</a>                       
                        </div>
                    </form>
                </div>
        </div>
    </body>
</html>

<?php
    //require '../config/banco.php';
    
    if(!empty($_POST))
    {
        //Acompanha os erros de validação
        $nomeErro = null;
        $cnpjErro = null;
        $emailErro = null;
        $senhaErro = null;
        
        $nome = $_POST['nome'];
        $cnpj = $_POST['cnpj'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
        //Validaçao dos campos:
        $validacao = true;
        
		if(empty($nome))
        {
            $nomeErro = 'Por favor digite o seu nome!';
            $validacao = false;
        }
        
        if(empty($cnpj))
        {
            $cnpjErro = 'Por favor digite o seu cnpj!';
            $validacao = false;
        }
        
        if(empty($email))
        {
            $telefoneErro = 'Por favor digite o endereço de email';
            $validacao = false;
        }
        elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) 
        {
            $emailError = 'Por favor digite um endereço de email válido!';
            $validacao = false;
        }
        
        if(empty($senha))
        {
            $senhaErro = 'Por favor digite sua senha';
            $validacao = false;
        }
        
		//atualizando no banco
        if($validacao)
        {
			try{
				$conexao = Banco::conectar();
			
				$sql = "UPDATE t_faculdades SET nm_faculdade='$nome', cnpj_faculdade='$cnpj',
							email_faculdade='$email', senha_faculdade='$senha' WHERE cd_faculdade=$id ;";

				mysql_query($sql,$conexao);

				$conexao = Banco::desconectar();
				
				header("Location: menu.php");
			}
			
			catch(Exception $ex){
				die('ERRO ao Atualizar: '.$exception->getMessage());
			}
        }
    }
?>