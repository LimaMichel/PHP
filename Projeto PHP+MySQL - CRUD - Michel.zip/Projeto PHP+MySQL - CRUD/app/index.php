<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		<title>Login</title>
    </head>
    
    <body>
        <div class="jumbotron">
        <div class="container">
            <div class="row">
                <h1>Seja Bem Vindo !</h1>
            </div>
            </br>
			
            <p>
            <a href="create.php" class="btn btn-success">Cadastrar</a>
            </p>
			</br>
			
			<h3>Realizar Login:</h3>
			
			<form class="form-horizontal" action="index.php" method="post">
			<div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
                <label class="control-label">Email</label>
                <div class="controls">
                    <input size="25" name="email" type="text" placeholder="Email" required="" value="<?php echo !empty($email)?$email: '';?>">
						<?php if(!empty($emailErro)): ?>
                            <span class="help-inline"><?php echo $emailErro;?></span>
                        <?php endif;?>
                </div>
            </div>
                        
            <div class="control-group <?php echo !empty($senhaErro)?'error ': '';?>">
                <label class="control-label" >Senha</label>
                <div class="controls">
                    <input size="25" name="senha" type="text" placeholder="Senha" required="" value="<?php echo !empty($senha)?$senha: '';?>">
                        <?php if(!empty($senhaErro)): ?>
							<span class="help-inline"><?php echo $senhaErro;?></span>
                        <?php endif;?>
                </div>
            </div>
			
			<div class="form-actions">
				<button type="submit" class="btn btn-success">Entrar</button>
			</div>
			
			</br>
			
			<div class="form-actions">
				<p>Duvidas, Sugestões, Reclamações ?</p>
				
				<a href="anexo_arquivo.php" type="btn" class="btn btn-default">Click Aqui</a>
			</div>
			
			</form>
		</div>
		</div>        
    </body>
</html>

<?php
    require '../config/banco.php';
    
    if(!empty($_POST))
    {
        //Acompanha os erros de validação
        $emailErro = null;
        $senhaErro = null;

        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
        //Validaçao dos campos:
        $validacao = true;
        
        if(empty($email))
        {
            $telefoneErro = 'Por favor digite o endereço de email';
            $validacao = false;
        }
        elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) 
        {
            $emailError = 'Por favor digite um endereço de email válido!';
            $validacao = false;
        }
        
        if(empty($senha))
        {
            $senhaErro = 'Por favor digite sua senha';
            $validacao = false;
        }
        
        //Pesquisando no Banco:
        if($validacao)
        {
			try{
				$conexao = Banco::conectar();
			
				$sql = "SELECT * FROM t_faculdades WHERE email_faculdade='$email' AND senha_faculdade='$senha' ;";

				$result = mysql_query($sql,$conexao);

				
				if(mysql_num_rows($result)>0){
					session_start();
	
					$_SESSION['email'] = $email;
					$_SESSION['senha'] = $senha;
					
					header("Location: menu.php");	
				}
				else{					
					echo '<html>
							<div class="jumbotron">
							<div class="container">
								<p>Dados de login inválidos, verifique !!</p> 
							</div>
							</div>
						</html>';
				}
				
				$conexao = Banco::desconectar();
			}
			
			catch(Exception $ex){
				die('Erro na Base de Dados:'.$exception->getMessage());
			}
        }
    }
?>