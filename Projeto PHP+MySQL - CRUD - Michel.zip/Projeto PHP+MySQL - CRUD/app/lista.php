<?php
session_start();

if ( !isset($_SESSION['email']) and !isset($_SESSION['senha']) ) {

	session_destroy();

	unset ($_SESSION['email']);
	unset ($_SESSION['senha']);

	header('location:index.php');
}

$login = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Listagem</title>
    </head>
    
    <body>
        </br>
		<div class="container">           
            <div class="span10 offset1">
				<a href="index.php" class="btn btn-success">Sair</a>
			</div>
		</div>
		
		<div class="jumbotron">
        <div class="container">
            <div class="row">
                <h1>Nossas Faculdades Cadastradas: </h1>
            </div>
            </br>
            <div class="row">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Instituição</th>
                            <th>CNPJ</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require '../config/banco.php';
						
						try{
							$conexao = Banco::conectar();
			
							$sql = "SELECT * FROM t_faculdades ORDER BY nm_faculdade ASC;";

							$result = mysql_query($sql,$conexao);
		
							while($sql = mysql_fetch_array($result)){
								echo '<tr>';
									echo '<td>'.$sql["nm_faculdade"].'</td>';
									echo '<td>'.$sql["cnpj_faculdade"].'</td>';
									echo '<td>'.$sql["email_faculdade"].'</td>';
								echo '</tr>';
							}
							$conexao = Banco::desconectar();
						}
						catch(Exception $ex){
							die('Erro na Base de Dados: '.$exception->getMessage());
						}   
                        ?>
                    </tbody>                   
                </table>
				
				<br/>
                <div class="form-actions">
                    <a href="menu.php" type="btn" class="btn btn-default">Voltar</a>
				</div>
				
            </div>
        </div>
        </div>
    </body>
</html>