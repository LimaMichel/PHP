<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
		
		<title>Duvidas, Sugestões, Reclamações ?</title>
    </head>
    
    <body>
	<div class="jumbotron">
    <div class="container">
	
	<form action="enviar.php" enctype="multipart/form-data" method="POST">
		<div class="control-group">
			<p>Escolha um arquivo em .txt com as informações que deseja:</p>
			
			<input name="arquivo" size="20" type="file" />
			
			<input type="submit" value="Enviar" />
		</div>
	</form>
	
	</div>
	</div>
	</body>
</html>