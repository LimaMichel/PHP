<?php

class Banco
{    
	private static $host = "localhost";
	private static $user = "root";
	private static $pass = "";
	private static $database = "Faculdade";
    private static $conexao = null;
    
    public static function conectar()
    {
        if(null == self::$conexao) //sintaxe para variaveis estaticas
        {
            try
            {
                //self = classe, this = objeto
				self::$conexao = mysql_connect(self::$host,self::$user,self::$pass);
				mysql_select_db(self::$database,self::$conexao);
				
				return self::$conexao;
			}
            catch(Exception $exception)
            {
                //equivalente ao exit()
				die($exception->getMessage());
            }
        }
        
    }
    
    public static function desconectar()
    {
        self::$conexao = null;
    }
}

?>
